# À déposer dans le projet CoDesign OS

Ce dossier est l’Academy (Next.js), prête à être fusionnée dans
https://sodexo-codesign-os.vercel.app
Un seul produit : CoDesign, OS, Academy, puis persona builder et les autres outils.

## Ce que tu fais

1. Télécharge `codesign-academy-pour-os.zip`.
2. Ouvre le chat Cursor **du projet qui déploie sodexo-codesign-os**.
3. Joins le zip.
4. Colle le message ci-dessous.

## Message à coller

Intègre ce zip dans le CoDesign OS. Je veux un seul site sur sodexo-codesign-os.vercel.app, pas une deuxième app.

- Header commun : CoDesign, OS, Academy. Garde de la place pour d’autres outils (persona builder, etc.).
- Après le login, une page d’accueil avec 3 entrées : CoDesign (/codesign), OS (les agents), Academy (/academy). La maquette est integrations/codesign-os/start.html, dans le style de l’OS.
- Garde les agents, le login (/api/auth) et le design actuels de l’OS.
- Relie chaque agent à sa formation. Le guide est dans src/app/os/agents/[slug]. Le branchement est décrit dans docs/OS_INTEGRATION.md.
- Déploie sur le projet Vercel existant sodexo-codesign-os.

## Dedans

- src/app/academy — les pages Academy
- src/app/codesign — offre et bibliothèque de credentials
- src/app/os — carte des agents et guides « comment se former »
- src/lib — méthode, credentials, XP
- public/credentials — visuels des 45 pages du deck
- integrations/codesign-os/start.html — page d’accueil à 3 entrées
- docs/OS_INTEGRATION.md — détail du branchement
